const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const User = require('../models/User');

const router = express.Router();

// ---------------- SIGNUP ----------------
router.post('/signup', [
  body('userType').isIn(['student', 'faculty']).withMessage('Invalid user type'),
  body('userId').notEmpty().withMessage('Student Roll No / Faculty ID is required'),
  body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 chars'),
  body('confirmPassword').custom((value, { req }) => {
    if (value !== req.body.password) throw new Error('Passwords do not match');
    return true;
  })
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { userId, password, userType } = req.body;

  try {
    let user = await User.findOne({ userId });
    if (user) return res.status(400).json({ message: 'User already exists' });

    const hashedPassword = await bcrypt.hash(password, 10);
    user = new User({ userId, password: hashedPassword, userType });
    await user.save();

    res.status(201).json({ message: 'User registered successfully', redirect: '/events' });
  } catch (err) {
    console.error("Signup Error:", err); // 🔥 Logs the real error to terminal
    res.status(500).json({ message: 'Server error during signup' });
  }
});

// ---------------- SIGNIN ----------------
router.post('/signin', async (req, res) => {
  const { userType, loginId, password } = req.body;

  try {
    const user = await User.findOne({ userId: loginId, userType });
    if (!user) return res.status(400).json({ message: 'Invalid credentials (user not found)' });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ message: 'Invalid credentials (wrong password)' });

    const token = jwt.sign(
      { userId: user._id, userType: user.userType },
      process.env.JWT_SECRET, // 👈 Ensure this is loaded properly!
      { expiresIn: '1h' }
    );

    res.json({ token, message: 'Login successful', redirect: '/events' });
  } catch (err) {
    console.error("Signin Error:", err); // 🔥 For debugging signin too
    res.status(500).json({ message: 'Server error during signin' });
  }
});

// ---------------- DEFAULT ----------------
router.get('/', (req, res) => {
  res.send("Auth route working for both student and faculty!");
});

module.exports = router;
