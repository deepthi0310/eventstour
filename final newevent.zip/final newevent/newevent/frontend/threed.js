// Setup Three.js Scene
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ alpha: true });

renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// Create Smoothly Floating Spheres
const spheres = [];
for (let i = 0; i < 8; i++) {
    let geometry = new THREE.SphereGeometry(1, 32, 32);
    let material = new THREE.MeshBasicMaterial({ color: Math.random() * 0xffffff, wireframe: true });
    let sphere = new THREE.Mesh(geometry, material);

    sphere.position.set(
        (Math.random() - 0.5) * 10, 
        (Math.random() - 0.5) * 10, 
        (Math.random() - 0.5) * 10
    );

    scene.add(sphere);
    spheres.push(sphere);
}

camera.position.z = 5;

// Smooth Floating Animation
function animate() {
    requestAnimationFrame(animate);

    spheres.forEach((sphere, index) => {
        let speed = 0.002 + index * 0.0005; // Slightly different speed for each sphere
        sphere.rotation.x += speed;
        sphere.rotation.y += speed;

        // Smooth roaming effect
        sphere.position.x += Math.sin(Date.now() * 0.0002 + index) * 0.02;
        sphere.position.y += Math.cos(Date.now() * 0.0003 + index) * 0.02;
        sphere.position.z += Math.sin(Date.now() * 0.0004 + index) * 0.02;
    });

    renderer.render(scene, camera);
}
animate();

// Adjust Scene on Window Resize
window.addEventListener("resize", () => {
    renderer.setSize(window.innerWidth, window.innerHeight);
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
});
